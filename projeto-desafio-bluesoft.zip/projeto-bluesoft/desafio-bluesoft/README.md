# teste-qa

Para rodar o projeto após o download, basta rodar na raíz do projeto:

mvn spring-boot:run

Após isso, abrir a aplicação no localhost:8080

É um projeto simples, com um formulário de cadastro de usuário e listagem na mesma tela.
Existe também uma busca por nome de usuário.

Projeto base para testes de automatização.
