package br.com.bluesoft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteQaApplicationTests {

	@Test
	void contextLoads() {
	}

}
