package br.com.bluesoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteQaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteQaApplication.class, args);
	}

}
